export interface MultiTabMessage {
  sender: string;
  type: string;
  payload: any;
  timestamp: number;
}