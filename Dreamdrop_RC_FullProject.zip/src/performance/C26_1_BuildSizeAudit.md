C-26.1 Build Size Reduction Audit initialized.
Next: collect module weight, dependency chains, unused assets.