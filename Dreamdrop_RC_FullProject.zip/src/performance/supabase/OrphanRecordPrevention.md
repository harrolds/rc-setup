# Orphan Record Prevention
This document will track foreign key integrity rules.