# Write Scope Checklist
- restrict client writes
- enforce update ownership
- prevent foreign key abuse