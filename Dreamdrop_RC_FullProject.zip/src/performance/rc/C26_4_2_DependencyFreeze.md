# C-26.4.2 Dependency Freeze
This file marks the dependency lock boundary for the RC.