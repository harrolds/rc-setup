# C-26.4.1 Bundle Audit
Will capture bundle size, hashing and tree-shake behavior.