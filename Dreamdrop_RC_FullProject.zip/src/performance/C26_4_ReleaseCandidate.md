C-26.4 — Release Candidate (RC) Build
This marks the RC initialization. Final bundling, SW validation and dependency freeze preparations are now in place.
