C-25.1 Shelter Zone Fixes applied:
- Safe-area tokens activated
- Global padding-top/bottom injected
- Panel/bottom-sheet/right-panel adapted for iOS homebar
- Viewport-fit correction prepared
