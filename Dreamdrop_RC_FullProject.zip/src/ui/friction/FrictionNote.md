C-25.2 Scroll + Panel Friction Tuning applied:
- Native feel curves added
- dragThreshold + velocity tuned
- overshoot + momentum calibrated
- panel + bottom-sheet physics engine added
- ghost scroll elimination configured
