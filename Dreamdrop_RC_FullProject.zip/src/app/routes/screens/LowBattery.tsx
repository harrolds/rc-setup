import React from 'react';

export default function LowBattery() {
  return <div>Low Battery Mode Enabled</div>;
}
