import React from 'react';

export default function Recorder() {
  return <div>Recorder</div>;
}
