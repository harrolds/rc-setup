import React from 'react';

export default function LowMemory() {
  return <div>Low Memory Mode Enabled</div>;
}
