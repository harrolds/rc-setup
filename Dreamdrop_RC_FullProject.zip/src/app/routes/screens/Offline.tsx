import React from 'react';

export default function Offline() {
  return <div>You are offline</div>;
}
