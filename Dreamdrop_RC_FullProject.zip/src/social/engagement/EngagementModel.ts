export interface EngagementStats {
  dreamId:string;
  likes:number;
  shares:number;
  views:number;
}
