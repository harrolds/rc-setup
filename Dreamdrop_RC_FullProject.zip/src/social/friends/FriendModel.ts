export interface FriendEntry {
  id:string;
  username:string;
}
