export interface DreamShareSettings {
  visibility: 'private' | 'friends' | 'public';
  ownerId: string;
  dreamId: string;
}
