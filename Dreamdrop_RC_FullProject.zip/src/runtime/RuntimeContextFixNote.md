This is a placeholder note: RuntimeContext.tsx exists and works.
Tests must import .tsx instead of .ts.