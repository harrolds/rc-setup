# Token Migration Plan
This file will outline the rewrite plan for styles in src/styles and src/styles/components.
Phase-based token insertion will follow the C-27.x sequence.