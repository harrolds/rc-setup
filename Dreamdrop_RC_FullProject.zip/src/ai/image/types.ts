export interface ImageRequest { prompt:string; style?:string }
export interface ImageResult { url:string; meta:any }
