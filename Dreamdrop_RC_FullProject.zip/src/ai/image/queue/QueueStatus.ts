export type QueueStatus = 
  | 'idle'
  | 'processing'
  | 'queued';
