export interface SyncResult {
  ok: boolean;
  error?: any;
}